<a href="command:gitlens.walkthrough.openCommunityVsPro" title="Learn about GitLens Community vs Pro">
  <img src="thumbnails/welcome.png" alt="Learn about GitLens Community vs Pro" />
</a>

Accelerate PR reviews, gain actionable code insights with visualizations, and streamline collaboration to supercharge your Git and VS Code experience. Leverage powerful workflows with GitLens Pro that will increase productivity for you and your team.

[Get started with GitLens Pro](command:gitlens.walkthrough.plus.signUp) free for 14 days — no credit card required.
