# Changelog

## 2.1 Minor
- 🚀 Truer color adjustment per theme variant
- 🐛 Fixed certain syntax colors
- 🔥♻️🎨 Code cleanup & refactor
- 🌈 added colors-used-table.md

## 2.0 Major
- 💄 Total revamp/rebranding from "Dracula Flat" to "Dracula.min"
- 🚀 Added "Dracula White" && "Dracula White Darker" themes!
- 🎨 Complete refactor of build scripts for clarity & readability