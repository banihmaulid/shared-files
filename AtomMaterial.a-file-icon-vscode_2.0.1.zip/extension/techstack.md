<!--
&lt;--- Readme.md Snippet without images Start ---&gt;
## Tech Stack
mallowigi/a-file-icon-vscode is built on the following main stack:

- [Mocha](http://mochajs.org/) – Javascript Testing Framework
- [Node.js](http://nodejs.org/) – Frameworks (Full Stack)
- [.NET](http://www.microsoft.com/net/) – Frameworks (Full Stack)
- [JavaScript](https://developer.mozilla.org/en-US/docs/Web/JavaScript) – Languages
- [TypeScript](http://www.typescriptlang.org) – Languages
- [Webpack](http://webpack.js.org) – JS Build Tools / JS Task Runners
- [ESLint](http://eslint.org/) – Code Review
- [Visual Studio Code](https://code.visualstudio.com/) – Text Editor
- [i18next](https://www.i18next.com/) – Translation Service
- [Prettier](https://prettier.io/) – Code Review
- [Puppeteer](https://github.com/GoogleChrome/puppeteer) – Headless Browsers
- [GitHub Actions](https://github.com/features/actions) – Continuous Integration

Full tech stack [here](/techstack.md)

&lt;--- Readme.md Snippet without images End ---&gt;

&lt;--- Readme.md Snippet with images Start ---&gt;
## Tech Stack
mallowigi/a-file-icon-vscode is built on the following main stack:

- <img width='25' height='25' src='https://img.stackshare.io/service/832/mocha.png' alt='Mocha'/> [Mocha](http://mochajs.org/) – Javascript Testing Framework
- <img width='25' height='25' src='https://img.stackshare.io/service/1011/n1JRsFeB_400x400.png' alt='Node.js'/> [Node.js](http://nodejs.org/) – Frameworks (Full Stack)
- <img width='25' height='25' src='https://img.stackshare.io/service/1014/IoPy1dce_400x400.png' alt='.NET'/> [.NET](http://www.microsoft.com/net/) – Frameworks (Full Stack)
- <img width='25' height='25' src='https://img.stackshare.io/service/1209/javascript.jpeg' alt='JavaScript'/> [JavaScript](https://developer.mozilla.org/en-US/docs/Web/JavaScript) – Languages
- <img width='25' height='25' src='https://img.stackshare.io/service/1612/bynNY5dJ.jpg' alt='TypeScript'/> [TypeScript](http://www.typescriptlang.org) – Languages
- <img width='25' height='25' src='https://img.stackshare.io/service/1682/IMG_4636.PNG' alt='Webpack'/> [Webpack](http://webpack.js.org) – JS Build Tools / JS Task Runners
- <img width='25' height='25' src='https://img.stackshare.io/service/3337/Q4L7Jncy.jpg' alt='ESLint'/> [ESLint](http://eslint.org/) – Code Review
- <img width='25' height='25' src='https://img.stackshare.io/service/4202/Visual_Studio_Code_logo.png' alt='Visual Studio Code'/> [Visual Studio Code](https://code.visualstudio.com/) – Text Editor
- <img width='25' height='25' src='https://img.stackshare.io/service/4747/default_82286a88bf01c80539ebd1d6dbea1b25df8af16d.png' alt='i18next'/> [i18next](https://www.i18next.com/) – Translation Service
- <img width='25' height='25' src='https://img.stackshare.io/service/7035/default_66f265943abed56bcdbfca1c866a4261b1fbb063.jpg' alt='Prettier'/> [Prettier](https://prettier.io/) – Code Review
- <img width='25' height='25' src='https://img.stackshare.io/service/7553/puppeteer.png' alt='Puppeteer'/> [Puppeteer](https://github.com/GoogleChrome/puppeteer) – Headless Browsers
- <img width='25' height='25' src='https://img.stackshare.io/service/11563/actions.png' alt='GitHub Actions'/> [GitHub Actions](https://github.com/features/actions) – Continuous Integration

Full tech stack [here](/techstack.md)

&lt;--- Readme.md Snippet with images End ---&gt;
-->
<div align="center">

# Tech Stack File
![](https://img.stackshare.io/repo.svg "repo") [mallowigi/a-file-icon-vscode](https://github.com/mallowigi/a-file-icon-vscode)![](https://img.stackshare.io/public_badge.svg "public")
<br/><br/>
|35<br/>Tools used|12/14/23 <br/>Report generated|
|------|------|
</div>

## <img src='https://img.stackshare.io/languages.svg'/> Languages (2)
<table><tr>
  <td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/1209/javascript.jpeg' alt='JavaScript'>
  <br>
  <sub><a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript">JavaScript</a></sub>
  <br>
  <sub></sub>
</td>

<td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/1612/bynNY5dJ.jpg' alt='TypeScript'>
  <br>
  <sub><a href="http://www.typescriptlang.org">TypeScript</a></sub>
  <br>
  <sub></sub>
</td>

</tr>
</table>

## <img src='https://img.stackshare.io/frameworks.svg'/> Frameworks (2)
<table><tr>
  <td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/1014/IoPy1dce_400x400.png' alt='.NET'>
  <br>
  <sub><a href="http://www.microsoft.com/net/">.NET</a></sub>
  <br>
  <sub></sub>
</td>

<td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/1011/n1JRsFeB_400x400.png' alt='Node.js'>
  <br>
  <sub><a href="http://nodejs.org/">Node.js</a></sub>
  <br>
  <sub></sub>
</td>

</tr>
</table>

## <img src='https://img.stackshare.io/devops.svg'/> DevOps (10)
<table><tr>
  <td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/3337/Q4L7Jncy.jpg' alt='ESLint'>
  <br>
  <sub><a href="http://eslint.org/">ESLint</a></sub>
  <br>
  <sub></sub>
</td>

<td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/1046/git.png' alt='Git'>
  <br>
  <sub><a href="http://git-scm.com/">Git</a></sub>
  <br>
  <sub></sub>
</td>

<td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/11563/actions.png' alt='GitHub Actions'>
  <br>
  <sub><a href="https://github.com/features/actions">GitHub Actions</a></sub>
  <br>
  <sub></sub>
</td>

<td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/832/mocha.png' alt='Mocha'>
  <br>
  <sub><a href="http://mochajs.org/">Mocha</a></sub>
  <br>
  <sub>v10.2.0</sub>
</td>

<td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/2637/6I3oEOP4_400x400.jpg' alt='NuGet'>
  <br>
  <sub><a href="https://www.nuget.org/">NuGet</a></sub>
  <br>
  <sub></sub>
</td>

<td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/7035/default_66f265943abed56bcdbfca1c866a4261b1fbb063.jpg' alt='Prettier'>
  <br>
  <sub><a href="https://prettier.io/">Prettier</a></sub>
  <br>
  <sub>v3.0.0</sub>
</td>

<td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/7553/puppeteer.png' alt='Puppeteer'>
  <br>
  <sub><a href="https://github.com/GoogleChrome/puppeteer">Puppeteer</a></sub>
  <br>
  <sub></sub>
</td>

<td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/4202/Visual_Studio_Code_logo.png' alt='Visual Studio Code'>
  <br>
  <sub><a href="https://code.visualstudio.com/">Visual Studio Code</a></sub>
  <br>
  <sub></sub>
</td>

</tr>
<tr>
  <td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/1682/IMG_4636.PNG' alt='Webpack'>
  <br>
  <sub><a href="http://webpack.js.org">Webpack</a></sub>
  <br>
  <sub>v5.88.1</sub>
</td>

<td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/1120/lejvzrnlpb308aftn31u.png' alt='npm'>
  <br>
  <sub><a href="https://www.npmjs.com/">npm</a></sub>
  <br>
  <sub></sub>
</td>

</tr>
</table>

## Other (2)
<table><tr>
  <td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/4747/default_82286a88bf01c80539ebd1d6dbea1b25df8af16d.png' alt='i18next'>
  <br>
  <sub><a href="https://www.i18next.com/">i18next</a></sub>
  <br>
  <sub></sub>
</td>

<td align='center'>
  <img width='36' height='36' src='https://img.stackshare.io/service/8443/2473585.png' alt='svgo'>
  <br>
  <sub><a href="https://github.com/svg/svgo">svgo</a></sub>
  <br>
  <sub></sub>
</td>

</tr>
</table>


## <img src='https://img.stackshare.io/group.svg' /> Open source packages (19)</h2>

## <img width='24' height='24' src='https://img.stackshare.io/service/1120/lejvzrnlpb308aftn31u.png'/> npm (19)

|NAME|VERSION|LAST UPDATED|LAST UPDATED BY|LICENSE|VULNERABILITIES|
|:------|:------|:------|:------|:------|:------|
|[@types/fs-extra](https://www.npmjs.com/@types/fs-extra)|v11.0.1|07/10/23|Elior |MIT|N/A|
|[@types/glob](https://www.npmjs.com/@types/glob)|v8.1.0|07/10/23|Elior |MIT|N/A|
|[@types/mocha](https://www.npmjs.com/@types/mocha)|v10.0.1|07/10/23|Elior |MIT|N/A|
|[@types/node](https://www.npmjs.com/@types/node)|v20.4.1|07/10/23|Elior |MIT|N/A|
|[@types/puppeteer](https://www.npmjs.com/@types/puppeteer)|v7.0.4|07/10/23|Elior |MIT|N/A|
|[@typescript-eslint/eslint-plugin](https://www.npmjs.com/@typescript-eslint/eslint-plugin)|v6.0.0|07/10/23|Elior |MIT|N/A|
|[@typescript-eslint/parser](https://www.npmjs.com/@typescript-eslint/parser)|v6.0.0|07/10/23|Elior |BSD-2-Clause|N/A|
|[eslint-config-prettier](https://www.npmjs.com/eslint-config-prettier)|v8.8.0|07/10/23|Elior |MIT|N/A|
|[eslint-plugin-import](https://www.npmjs.com/eslint-plugin-import)|v2.27.5|07/10/23|Elior |MIT|N/A|
|[eslint-plugin-prettier](https://www.npmjs.com/eslint-plugin-prettier)|v4.2.1|07/10/23|Elior |MIT|N/A|
|[eslint-plugin-unicorn](https://www.npmjs.com/eslint-plugin-unicorn)|v47.0.0|07/10/23|Elior |MIT|N/A|
|[fs-extra](https://www.npmjs.com/fs-extra)|v11.1.1|07/10/23|Elior |MIT|N/A|
|[glob](https://www.npmjs.com/glob)|v7.2.3|07/10/23|Elior |ISC|N/A|
|[lodash.merge](https://www.npmjs.com/lodash.merge)|v4.6.2|07/10/23|Elior |MIT|N/A|
|[rimraf](https://www.npmjs.com/rimraf)|v3.0.2|07/10/23|Elior |ISC|N/A|
|[ts-loader](https://www.npmjs.com/ts-loader)|v9.4.4|07/10/23|Elior |MIT|N/A|
|[ts-node](https://www.npmjs.com/ts-node)|v10.9.1|07/10/23|Elior |MIT|N/A|
|[tsconfig-paths](https://www.npmjs.com/tsconfig-paths)|v3.14.1|07/10/23|Elior |MIT|N/A|
|[webpack-cli](https://www.npmjs.com/webpack-cli)|v5.1.4|07/10/23|Elior |MIT|N/A|

<br/>
<div align='center'>

Generated via [Stack File](https://github.com/marketplace/stack-file)
